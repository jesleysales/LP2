﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PFilmes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnExe_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[6, 2];
            string aux;
            double media1 = 0, media2 = 0;

            lstBxNotas.Items.Clear();

            for (var i = 0; i < 6; i++)
            {
                for (var j = 0; j < 2; j++)
                {
                    aux = Interaction.InputBox("Digite a nota do Filme: " + (j + 1), "Entrada de Notas pessoa " + (i + 1));

                    if (!double.TryParse(aux, out notas[i, j]))
                    {
                        MessageBox.Show("Nota Inválida");
                        j--;
                    }
                    else
                    {
                        if (notas[i, j] < 0 || notas[i, j] > 10)
                        {
                            MessageBox.Show("Nota Inválida");
                            j--;
                        }
                        else
                        {
                            if (j == 0)
                            {
                                media1 += notas[i, j];
                            }
                            else
                            {
                                media2 += notas[i, j];
                            }
                        }
                    }

                }
            }
            for (var i = 0; i < 6; i++)
            {
                lstBxNotas.Items.Add("Pessoa " + (i + 1) + ": Nota do Primeiro Filme: " + notas[i, 0].ToString("N2") + " Nota do Segundo Filme: " + notas[i, 1].ToString("N2"));
            }

            lstBxNotas.Items.Add("---------------------------------");

            lstBxNotas.Items.Add("Média do Primeiro Filme : " + (media1 /= 10).ToString("N2"));
            lstBxNotas.Items.Add("Média do Segundo Filme : " + (media2 /= 10).ToString("N2"));
        }   
    }
}
